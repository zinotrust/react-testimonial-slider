import "./App.scss";
import Testimonial from "./components/Testimonial/Testimonial";

function App() {
  return (
    <div>
      <Testimonial />
    </div>
  );
}

export default App;
